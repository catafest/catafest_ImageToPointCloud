# catafest_ImageToPointCloud

This Blender extension creates a 3D point cloud from multiple images.
It includes controls to adjust axis spacing and avoid depth distortion caused by focal differences.