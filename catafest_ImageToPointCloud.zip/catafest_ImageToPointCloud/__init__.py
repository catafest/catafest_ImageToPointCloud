import bpy
import os
from bpy.props import StringProperty, FloatProperty, CollectionProperty
from bpy.types import Operator, Panel, PropertyGroup, AddonPreferences

class CATAFEST_PT_Props(PropertyGroup):
    offset_x: FloatProperty(name="Offset X", default=0.0)
    offset_y: FloatProperty(name="Offset Y", default=0.0)
    offset_z: FloatProperty(name="Offset Z", default=0.0)

class CATAFEST_OT_select_images(Operator):
    bl_idname = "catafest.select_images"
    bl_label = "Select Images"
    bl_description = "Select multiple images to create planes"

    directory: StringProperty(subtype='DIR_PATH')
    files: CollectionProperty(type=bpy.types.PropertyGroup)

    def execute(self, context):
        props = context.scene.catafest_props
        offset_x = props.offset_x
        offset_y = props.offset_y
        offset_z = props.offset_z

        for i, file in enumerate(self.files):
            image_path = os.path.join(self.directory, file.name)
            if not image_path.lower().endswith(('.jpg', '.jpeg', '.png')):
                continue

            img = bpy.data.images.load(image_path)

            # Material with image texture
            mat = bpy.data.materials.new(name=f"Mat_{file.name}")
            mat.use_nodes = True
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            tex_image = mat.node_tree.nodes.new('ShaderNodeTexImage')
            tex_image.image = img
            mat.node_tree.links.new(bsdf.inputs['Base Color'], tex_image.outputs['Color'])

            # Create plane
            bpy.ops.mesh.primitive_plane_add(size=2)
            plane = bpy.context.active_object
            plane.name = f"Plane_{file.name}"
            plane.data.materials.append(mat)

            # Offset plane
            plane.location.x = i * offset_x
            plane.location.y = i * offset_y
            plane.location.z = i * offset_z

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class CATAFEST_PT_panel(Panel):
    bl_label = "Image to Point Cloud"
    bl_idname = "CATAFEST_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'catafest_3D'

    def draw(self, context):
        layout = self.layout
        props = context.scene.catafest_props

        layout.prop(props, "offset_x")
        layout.prop(props, "offset_y")
        layout.prop(props, "offset_z")
        layout.operator("catafest.select_images", text="Select Images")

def register():
    bpy.utils.register_class(CATAFEST_PT_Props)
    bpy.utils.register_class(CATAFEST_OT_select_images)
    bpy.utils.register_class(CATAFEST_PT_panel)
    bpy.types.Scene.catafest_props = bpy.props.PointerProperty(type=CATAFEST_PT_Props)

def unregister():
    bpy.utils.unregister_class(CATAFEST_PT_Props)
    bpy.utils.unregister_class(CATAFEST_OT_select_images)
    bpy.utils.unregister_class(CATAFEST_PT_panel)
    del bpy.types.Scene.catafest_props

if __name__ == "__main__":
    register()